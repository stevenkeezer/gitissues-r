/* This file is auto generated, version 201606121131 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#201606121131 SMP Sun Jun 12 15:49:45 UTC 2016"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 5.3.1 20160528 (Ubuntu 5.3.1-21ubuntu11) "
